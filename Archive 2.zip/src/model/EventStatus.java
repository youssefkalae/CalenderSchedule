package model;

/**
 * Enum for event status (public/private).
 */
public enum EventStatus {
  PUBLIC, PRIVATE
}